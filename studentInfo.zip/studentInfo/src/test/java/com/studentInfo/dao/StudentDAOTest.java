package com.studentInfo.dao;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.studentInfo.entity.Student;

import javax.annotation.Resource;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by 15799 on 2016/7/7.
 */
@RunWith(SpringJUnit4ClassRunner.class)
//告诉junit spring文件
@ContextConfiguration("classpath:spring/spring-dao.xml")
public class StudentDAOTest {
    //注入DAO依赖
    @Resource
    private StudentDAO studentDAO;
    @Test
    public void queryById() throws Exception {
            long id = 10020;
            Student student = studentDAO.queryById(id);
            System.out.println(student.getName());
            System.out.println(student);
        /**
         * 张三
         Student{studentId=10020, name='张三', sex='男', score=90}
         */

    }

    @Test
    public void queryAll() throws Exception {
        List<Student> students = studentDAO.queryAll(0,100);
        for(Student student : students)
        {
            System.out.println(student);
        }
        /*
        Student{studentId=10022, name='张三', sex='男', score=90}
        Student{studentId=10021, name='张三', sex='男', score=90}
        Student{studentId=10020, name='张三', sex='男', score=90}
        Student{studentId=10019, name='小王', sex='男', score=85}
        Student{studentId=10018, name='小明', sex='男', score=91}
        Student{studentId=10017, name='李四', sex='男', score=70}
        Student{studentId=10016, name='张三', sex='男', score=90}
         */
    }

    @Test
    public void addStudent() throws Exception {
        studentDAO.addStudent("李华","男",99);
        /*
        * 17:17:36.049 [main] DEBUG com.studentInfo.dao.StudentDAO.addStudent - ==> Parameters: 李华(String), 男(String), 99(Integer)
        17:17:36.097 [main] DEBUG com.studentInfo.dao.StudentDAO.addStudent - <==    Updates: 1
        * */
    }

    @Test
    public void deleteStudent() throws Exception {
        studentDAO.deleteStudent(10022);
        /*
        17:25:38.563 [main] DEBUG com.studentInfo.dao.StudentDAO.deleteStudent - ==> Parameters: 10022(Long)
        17:25:38.626 [main] DEBUG com.studentInfo.dao.StudentDAO.deleteStudent - <==    Updates: 1
        * */
    }

    @Test
    public void changeStudentInfo() throws Exception {
            studentDAO.changeStudentInfo(10021,"王明","男",90);
        /*
            17:28:57.017 [main] DEBUG com.studentInfo.dao.StudentDAO.changeStudentInfo - ==> Parameters: 王明(String), 男(String), 90(Integer), 10021(Long)
            17:28:57.060 [main] DEBUG com.studentInfo.dao.StudentDAO.changeStudentInfo - <==    Updates: 1
         */
    }

}