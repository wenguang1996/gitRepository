package com.studentInfo.service;

import com.studentInfo.entity.Student;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by 15799 on 2016/7/8.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({
            "classpath:spring/spring-dao.xml",
            "classpath:spring/spring-service.xml"
        })
public class StudentInfoServiceTest {
    private  final Logger logger = LoggerFactory.getLogger(this.getClass());
    @Autowired
    private StudentInfoService studentInfoService;
    @Test
    public void getStudentInfo() throws Exception {
        List<Student> students = studentInfoService.getStudentInfo();
        for(Student student:students)
        {
            System.out.println(student);
        }
        /**\
         * Student{studentId=10023, name='李华', sex='男', score=99}
            Student{studentId=10021, name='王明', sex='男', score=90}
            Student{studentId=10020, name='张三', sex='男', score=90}
            Student{studentId=10019, name='小王', sex='男', score=85}
            Student{studentId=10018, name='小明', sex='男', score=91}
            Student{studentId=10017, name='李四', sex='男', score=70}
            Student{studentId=10016, name='张三', sex='男', score=90}
         */
    }

    @Test
    public void getStudentInfoById() throws Exception {
        Student student = studentInfoService.getStudentInfoById(10021);
        System.out.println(student);
        /**
         * Student{studentId=10021, name='王明', sex='男', score=90}
         */
    }

    @Test
    public void deleteStudentById() throws Exception {
        studentInfoService.deleteStudentById(10044);
    }

    @Test
    public void addStudentInfo() throws Exception {
        studentInfoService.addStudentInfo("星星","男",67);
    }

    @Test
    public void changeStudentInfo() throws Exception {
        studentInfoService.changeStudentInfo(10047,"tom","male",70);
    }

}