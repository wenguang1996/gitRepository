package com.studentInfo.service;

import com.studentInfo.entity.Student;
import com.studentInfo.exception.addFailException;
import com.studentInfo.exception.changeFailException;
import com.studentInfo.exception.deleteFailException;
import com.studentInfo.exception.queryException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by 15799 on 2016/7/8.
 */
public interface StudentInfoService {

    //查询所有学生信息

    List<Student> getStudentInfo();

    //根据id查询学生信息
    Student getStudentInfoById(long id) throws queryException;

    //删除学生信息
    int deleteStudentById(long id) throws deleteFailException;

    //添加学生信息
    int addStudentInfo(String name,String sex,int score) throws addFailException;

    //修改学生信息
    int changeStudentInfo(long id,String name,String sex,int score) throws changeFailException;

}
