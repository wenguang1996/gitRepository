package com.studentInfo.service.impl;

import com.studentInfo.dao.StudentDAO;
import com.studentInfo.entity.Student;
import com.studentInfo.exception.addFailException;
import com.studentInfo.exception.changeFailException;
import com.studentInfo.exception.deleteFailException;
import com.studentInfo.exception.queryException;
import com.studentInfo.service.StudentInfoService;
import org.slf4j.Logger;import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by 15799 on 2016/7/8.
 */
@Service
public class studentInfoServiceimpl implements StudentInfoService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private StudentDAO studentDAO;
    public List<Student> getStudentInfo() {
        return studentDAO.queryAll(0,7);
    }

    public Student getStudentInfoById(long id) throws queryException {
        return studentDAO.queryById(id);
    }

    public int deleteStudentById(long id) throws deleteFailException {

            return studentDAO.deleteStudent(id);
    }

    public int addStudentInfo(String name, String sex, int score) throws addFailException {

        return studentDAO.addStudent(name,sex,score);
    }

    public int changeStudentInfo(long id, String name, String sex, int score) throws changeFailException {

        return studentDAO.changeStudentInfo(id, name, sex, score);
    }
}
