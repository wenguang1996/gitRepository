package com.studentInfo.dao;
import com.studentInfo.entity.Student;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by 15799 on 2016/7/6.
 */
public interface StudentDAO {
    /*
        根据Id查询
     */
    Student queryById(long studentId);

    /*
            查询所有
     */
    List<Student> queryAll(@Param("offset") int offset, @Param("limit") int limit);

    /*
        添加学生信息
     */
    int addStudent(@Param("name") String name,@Param("sex") String sex, @Param("score")int score);

    /*
        删除学生信息
     */
    int deleteStudent(long id);

    /*
        修改学生信息
     */
    int changeStudentInfo(@Param("id") long id,@Param("name") String name,@Param("sex") String sex,@Param("score") int score);
}
