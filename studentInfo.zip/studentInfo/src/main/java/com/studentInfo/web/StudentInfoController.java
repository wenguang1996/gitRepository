package com.studentInfo.web;

import com.studentInfo.entity.Student;
import com.studentInfo.service.StudentInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created by 15799 on 2016/7/8.
 */
@Controller
@RequestMapping("/studentInfo")
public class StudentInfoController {
    @Autowired
    private StudentInfoService studentInfoService;
    @RequestMapping(value = "/all",method = RequestMethod.GET,produces = {"application/json;charset=UTF-8"})
    @ResponseBody
    public List<Student> getAll(Model model)
    {
        List<Student> students = studentInfoService.getStudentInfo();
        return  students;
    }
    @RequestMapping(value = "/{id}",method = RequestMethod.GET,produces = {"application/json;charset=UTF-8"})
    @ResponseBody
    public Student getById(@PathVariable("id") long id,Model model)
    {
        Student student = studentInfoService.getStudentInfoById(id);
        return student;
    }
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public String  addStudentInfo(@RequestParam(value = "name") String name,@RequestParam(value = "sex") String sex,@RequestParam(value = "score") int score)
    {
        if(0 != studentInfoService.addStudentInfo(name, sex, score))
        {
            return "success";
        }
        else
        {
            return "fail";
        }
    }
    @RequestMapping(value = "/delete",method = RequestMethod.POST)
    public String deleteStudentInfo(@RequestParam("id") long id)
    {

        if(0 != studentInfoService.deleteStudentById(id))
        {
            return "success";
        }
        else
        {
            return "fail";
        }
    }
    @RequestMapping(value = "/change",method = RequestMethod.POST)
    public String changeStudentInfo(@RequestParam(value = "id") long id,@RequestParam(value = "name") String name,@RequestParam(value = "sex") String sex,@RequestParam("value = score") int score)
    {
        if(0 != studentInfoService.deleteStudentById(id))
        {
            return "success";
        }
        else
        {
            return "fail";
        }
    }

    @RequestMapping(value = "/test")
    public String testPage(){
        return "test";
    }
}
