package com.studentInfo.entity;

/**
 * Created by 15799 on 2016/7/6.
 */
public class Student {
    private long studentId;
    private String name;
    private String sex;
    private int score;


    public int getScore() {
        return score;
    }

    public long getStudentId() {
        return studentId;
    }

    public String getName() {
        return name;
    }

    public String getSex() {
        return sex;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }


    @Override
    public String toString() {
        return "Student{" +
                "studentId=" + studentId +
                ", name='" + name + '\'' +
                ", sex='" + sex + '\'' +
                ", score=" + score +
                '}';
    }
}
