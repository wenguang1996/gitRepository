package com.studentInfo.exception;

/**
 * Created by 15799 on 2016/7/8.
 */

/**
 * 添加失败异常
 */
public class addFailException extends RuntimeException{
    public addFailException(String message) {
        super(message);
    }

    public addFailException(String message, Throwable cause) {
        super(message, cause);
    }
}
