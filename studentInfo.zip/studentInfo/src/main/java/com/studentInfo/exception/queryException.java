package com.studentInfo.exception;

/**
 * Created by 15799 on 2016/7/8.
 */
public class queryException extends RuntimeException {
    public queryException(String message, Throwable cause) {
        super(message, cause);
    }

    public queryException(String message) {
        super(message);
    }
}
