package com.studentInfo.exception;

/**
 * Created by 15799 on 2016/7/8.
 */

/**\
 * 修改失败异常
 */
public class changeFailException extends  RuntimeException {
    public changeFailException(String message) {
        super(message);
    }

    public changeFailException(String message, Throwable cause) {
        super(message, cause);
    }
}
