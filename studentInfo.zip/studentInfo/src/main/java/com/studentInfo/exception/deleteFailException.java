package com.studentInfo.exception;

/**
 * Created by 15799 on 2016/7/8.
 */

/**
 * 删除失败异常
 */
public class deleteFailException extends RuntimeException{
    public deleteFailException(String message) {
        super(message);
    }

    public deleteFailException(String message, Throwable cause) {
        super(message, cause);
    }
}
