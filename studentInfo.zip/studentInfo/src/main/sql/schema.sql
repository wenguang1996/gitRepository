--数据库初始化脚本

--创建数据库
CREATE DATABASE student;
--使用数据库
use student;

--创建学生信息表
CREATE TABLE Student_T (
  student_id bigint NOT NULL AUTO_INCREMENT,
  name char(8) NOT NULL,
  sex char(2) DEFAULT'男',
  score int NOT NULL,
  PRIMARY KEY(student_id)
)ENGINE = InnoDB AUTO_INCREMENT = 10000 DEFAULT CHARSET=utf8;

insert into Student_T(name,sex,score)
    VALUES
    ('张三','男',90),
    ('李四','男',70),
    ('小明','男',91),
    ('小王','男',85),
    ('张三','男',90),
    ('张三','男',90),
    ('张三','男',90);